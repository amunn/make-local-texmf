#!/bin/sh
open `/Library/TeX/texbin/kpsewhich -var-value TEXMFHOME`

